document.getElementsByTagName("h1")[0].style.fontSize = "6vw";
var count = 0;
    var counterElement = document.getElementById("counter");

    function increment() {
      count++;
      counterElement.textContent = count;
    }